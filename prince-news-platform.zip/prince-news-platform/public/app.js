const LANGS = [
  ["en","English"],["ur","اردو"],["hi","हिन्दी"],["ar","العربية"],["bn","বাংলা"],["zh","中文"],["es","Español"],["fr","Français"],["de","Deutsch"],["pt","Português"],["ru","Русский"],["ja","日本語"],["ko","한국어"],["id","Bahasa Indonesia"],["tr","Türkçe"],["it","Italiano"],["nl","Nederlands"],["pa","ਪੰਜਾਬੀ"],["ta","தமிழ்"],["te","తెలుగు"],["mr","मराठी"],["fa","فارسی"],["sw","Kiswahili"],["vi","Tiếng Việt"],["th","ไทย"],["uk","Українська"],["pl","Polski"],["ro","Română"],["he","עברית"],["ms","Bahasa Melayu"],["fil","Filipino"],["ne","नेपाली"],["si","සිංහල"],["ps","پښتو"],["ku","Kurdî"]
];
const UI = {
 en:{tag:"Your world, your news",breaking:"BREAKING",latest:"Latest News",all:"All",Pakistan:"Pakistan",World:"World",Sports:"Sports",Technology:"Technology",Entertainment:"Entertainment",search:"Search headlines...",footer:"News for everyone, in more languages.",empty:"No stories found. Try another search or category.",demo:"News",read:"Read original source"},
 ur:{tag:"Aap ki duniya, aap ki khabrein",breaking:"Aham khabar",latest:"Taza tareen khabrein",all:"Tamam",Pakistan:"Pakistan",World:"Duniya",Sports:"Khel",Technology:"Technology",Entertainment:"Tafreeh",search:"Khabrein talash karein...",footer:"Har shakhs ke liye khabrein, kai zabanon mein.",empty:"Koi khabar nahi mili.",demo:"Khabar",read:"Asal source parhein"},
 hi:{tag:"आपकी दुनिया, आपकी खबरें",breaking:"बड़ी खबर",latest:"ताज़ा खबरें",all:"सभी",Pakistan:"पाकिस्तान",World:"दुनिया",Sports:"खेल",Technology:"तकनीक",Entertainment:"मनोरंजन",search:"खबर खोजें...",footer:"हर किसी के लिए, कई भाषाओं में खबरें।",empty:"कोई खबर नहीं मिली।",demo:"खबर",read:"मूल स्रोत पढ़ें"},
 ar:{tag:"عالمك، أخبارك",breaking:"عاجل",latest:"آخر الأخبار",all:"الكل",Pakistan:"باكستان",World:"العالم",Sports:"رياضة",Technology:"تقنية",Entertainment:"ترفيه",search:"ابحث عن الأخبار...",footer:"أخبار للجميع بلغات متعددة.",empty:"لم يتم العثور على أخبار.",demo:"خبر",read:"اقرأ المصدر الأصلي"},
 es:{tag:"Tu mundo, tus noticias",breaking:"ÚLTIMA HORA",latest:"Últimas noticias",all:"Todo",Pakistan:"Pakistán",World:"Mundo",Sports:"Deportes",Technology:"Tecnología",Entertainment:"Entretenimiento",search:"Buscar noticias...",footer:"Noticias para todos, en más idiomas.",empty:"No se encontraron noticias.",demo:"Noticia",read:"Leer fuente original"},
 fr:{tag:"Votre monde, vos actualités",breaking:"URGENT",latest:"Dernières actualités",all:"Tout",Pakistan:"Pakistan",World:"Monde",Sports:"Sport",Technology:"Technologie",Entertainment:"Divertissement",search:"Rechercher...",footer:"Des actualités pour tous, en plusieurs langues.",empty:"Aucun article trouvé.",demo:"Actualité",read:"Lire la source originale"}
};
let category="All", lang="en", articles=[];
const $=id=>document.getElementById(id);
function t(key){return (UI[lang]&&UI[lang][key])||UI.en[key]||key}
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function img(url,title,cls=""){if(!url)return "";return `<img class="${cls}" loading="lazy" src="${esc(url)}" alt="${esc(title)}" onerror="this.style.display='none'">`}
function date(s){try{return new Date(s).toLocaleDateString(lang||"en",{year:"numeric",month:"short",day:"numeric"})}catch{return ""}}
function storyCard(a){return `<article class="news-card">${img(a.image_url,a.title)}<div class="card-copy"><span class="pill">${esc(a.category)}</span><h2>${esc(a.title)}</h2><p>${esc(a.summary||a.body||"")}</p><div class="meta">${esc(a.source_name||"Prince News")} • ${date(a.published_at||a.created_at)}</div>${a.source_url?`<a class="source-link" href="${esc(a.source_url)}" target="_blank" rel="noopener noreferrer">${t("read")} ↗</a>`:""}</div></article>`}
function render(){
 const filtered=articles.filter(a=>(category==="All"||a.category===category));
 const cats=["All","Pakistan","World","Sports","Technology","Entertainment"];
 $("categories").innerHTML=cats.map(c=>`<button class="${category===c?"active":""}" data-category="${c}">${t(c)}</button>`).join("");
 $("categories").querySelectorAll("button").forEach(b=>b.onclick=()=>{category=b.dataset.category;loadArticles()});
 $("latestTitle").textContent=t("latest");$("tagline").textContent=t("tag");$("breakingLabel").textContent=t("breaking");$("footerNote").textContent=t("footer");$("search").placeholder=t("search");
 $("dateLine").textContent="PRINCE NEWS • "+new Date().toLocaleDateString(lang||"en",{dateStyle:"full"});$("year").textContent=new Date().getFullYear();
 document.documentElement.lang=lang;document.documentElement.dir=["ar","ur","fa","he","ps"].includes(lang)?"rtl":"ltr";
 $("count").textContent=filtered.length+" stories";
 if(!filtered.length){$("featured").innerHTML="";$("articles").innerHTML=`<p class="empty">${t("empty")}</p>`;return}
 const a=filtered[0], rest=filtered.slice(1);
 $("breakingText").textContent=a.title;
 $("featured").innerHTML=`<article class="feature-main">${img(a.image_url,a.title)}<div class="feature-copy"><span class="pill">${esc(a.category)}</span><h2>${esc(a.title)}</h2><p>${esc(a.summary||a.body||"")}</p><div class="meta">${esc(a.source_name||"Prince News")} • ${date(a.published_at||a.created_at)}</div>${a.source_url?`<a class="source-link" href="${esc(a.source_url)}" target="_blank" rel="noopener noreferrer">${t("read")} ↗</a>`:""}</div></article><div class="feature-side">${rest.slice(0,2).map(x=>`<article class="side-card">${img(x.image_url,x.title)}<div><span class="pill">${esc(x.category)}</span><h3>${esc(x.title)}</h3><div class="meta">${esc(x.source_name||"Prince News")}</div></div></article>`).join("")}</div>`;
 $("articles").innerHTML=rest.length?rest.map(storyCard).join(""):`<p class="empty">${t("empty")}</p>`;
}
async function loadArticles(){
 const q=$("search").value.trim();
 try{const r=await fetch(`/api/articles?limit=100${category!=="All"?"&category="+encodeURIComponent(category):""}${q?"&q="+encodeURIComponent(q):""}`);if(!r.ok)throw new Error();articles=await r.json();render()}
 catch{$("articles").innerHTML='<p class="empty">Could not load stories. Please refresh the page.</p>'}
}
function fillLanguages(){$("language").innerHTML=LANGS.map(([code,name])=>`<option value="${code}">${name}</option>`).join("");$("language").value=lang}
$("language").addEventListener("change",e=>{lang=e.target.value;render()});
let searchTimer;$("search").addEventListener("input",()=>{clearTimeout(searchTimer);searchTimer=setTimeout(loadArticles,250)});
fillLanguages();loadArticles();
